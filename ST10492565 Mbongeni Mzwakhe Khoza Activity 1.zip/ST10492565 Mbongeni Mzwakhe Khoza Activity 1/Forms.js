function validateForm(formId) {
  const form = document.getElementById(formId);
  const inputs = form.querySelectorAll('input, textarea, select');
  let valid = true;

  inputs.forEach(input => {
    if (!input.checkValidity()) {
      input.classList.add('error');
      valid = false;
    } else {
      input.classList.remove('error');
    }
  });

  return valid;
}

function submitForm(formId) {
  if (!validateForm(formId)) {
    alert("Please correct the errors.");
    return;
  }

  const form = document.getElementById(formId);
  const data = new FormData(form);

  // Simulate email sending (requires server or backend service like EmailJS)
  console.log("Form submitted with data:", Object.fromEntries(data));

  alert("Thank you! Your form has been submitted.");
  form.reset();
}

// Attach handlers
document.getElementById('services-form')?.addEventListener('submit', e => {
  e.preventDefault();
  submitForm('services-form');
});
document.getElementById('contact-form')?.addEventListener('submit', e => {
  e.preventDefault();
  submitForm('contact-form');
});
