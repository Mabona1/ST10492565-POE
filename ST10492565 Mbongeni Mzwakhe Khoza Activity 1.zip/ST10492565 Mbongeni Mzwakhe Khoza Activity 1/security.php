<?php
// security.php — Add security HTTP headers

// Prevent clickjacking
header('X-Frame-Options: SAMEORIGIN');

// Enable XSS protection
header('X-XSS-Protection: 1; mode=block');

// Prevent MIME sniffing
header('X-Content-Type-Options: nosniff');

// Content Security Policy (adjust as needed)
header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; script-src 'self'; style-src 'self';");

// Referrer policy for privacy
header('Referrer-Policy: no-referrer-when-downgrade');

// Uncomment if you have HTTPS enabled:
// header('Strict-Transport-Security: max-age=31536000; includeSubDomains; preload');
?>
