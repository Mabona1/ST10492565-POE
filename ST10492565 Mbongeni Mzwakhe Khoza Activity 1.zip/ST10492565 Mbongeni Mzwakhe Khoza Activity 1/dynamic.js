// Simulate fetching posts/products
const items = [
  { id: 1, name: "Service A" },
  { id: 2, name: "Service B" },
  { id: 3, name: "Consulting" }
];

// Load content
function loadContent() {
  const container = document.getElementById('content');
  items.forEach(item => {
    const el = document.createElement('div');
    el.textContent = item.name;
    container.appendChild(el);
  });
}

// Search Filter
document.getElementById('search-input').addEventListener('input', function () {
  const value = this.value.toLowerCase();
  document.querySelectorAll('#content div').forEach(el => {
    el.style.display = el.textContent.toLowerCase().includes(value) ? '' : 'none';
  });
});
