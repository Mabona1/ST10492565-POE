window.addEventListener('load', () => {
    const isLoggedIn = sessionStorage.getItem('loggedIn');
  
    if (!isLoggedIn) {
      // Check if user has previously registered
      const storedUsername = localStorage.getItem('username');
      const storedPassword = localStorage.getItem('password');
  
      if (!storedUsername || !storedPassword) {
        // Registration
        const newUsername = prompt("Welcome! Please create a username:");
        const newPassword = prompt("Now create a password:");
  
        if (newUsername && newPassword) {
          localStorage.setItem('username', newUsername);
          localStorage.setItem('password', newPassword);
          alert("Registration successful! Please log in.");
        } else {
          alert("Registration failed. Please reload and try again.");
          document.body.innerHTML = "<h1>Access Denied</h1>";
          return;
        }
      }
  
      // Login
      let attempts = 3;
      while (attempts > 0) {
        const username = prompt("Enter your username:");
        const password = prompt("Enter your password:");
  
        if (
          username === localStorage.getItem('username') &&
          password === localStorage.getItem('password')
        ) {
          alert(Welcome back, ${username}!);
          sessionStorage.setItem('loggedIn', true);
          break;
        } else {
          attempts--;
          alert(Incorrect credentials. Attempts remaining: ${attempts});
        }
      }
  
      if (attempts === 0) {
        alert("Access denied. Reload the page to try again.");
        document.body.innerHTML = "<h1>Access Denied</h1>";
      }
    }
  });