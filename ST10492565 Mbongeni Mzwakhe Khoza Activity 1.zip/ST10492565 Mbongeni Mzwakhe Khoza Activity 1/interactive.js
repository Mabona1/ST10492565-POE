// Accordion
document.querySelectorAll('.accordion-toggle').forEach(button => {
  button.addEventListener('click', () => {
    const content = button.nextElementSibling;
    content.classList.toggle('active');
    content.style.maxHeight = content.classList.contains('active') ? content.scrollHeight + 'px' : null;
  });
});

// Tabs
document.querySelectorAll('.tab-button').forEach(button => {
  button.addEventListener('click', () => {
    const tabContentId = button.dataset.tab;
    document.querySelectorAll('.tab-content').forEach(tab => tab.style.display = 'none');
    document.getElementById(tabContentId).style.display = 'block';
  });
});

// Modal
const modal = document.getElementById("modal");
document.querySelectorAll('.open-modal').forEach(btn => {
  btn.addEventListener('click', () => modal.style.display = 'block');
});
document.getElementById("close-modal").addEventListener('click', () => modal.style.display = 'none');

// Lightbox
document.querySelectorAll('.gallery img').forEach(img => {
  img.addEventListener('click', () => {
    const lightbox = document.getElementById('lightbox');
    lightbox.querySelector('img').src = img.src;
    lightbox.classList.add('active');
  });
});
document.getElementById('lightbox').addEventListener('click', () => {
  document.getElementById('lightbox').classList.remove('active');
});

// Google Maps (Include this in <head>: <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY"></script>)
function initMap() {
  const location = { lat: -25.344, lng: 131.036 };
  new google.maps.Map(document.getElementById("map"), {
    zoom: 4,
    center: location,
  });
}
